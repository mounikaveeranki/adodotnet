﻿
using System.Windows;
using System.Windows.Controls;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using IGATEPATNI.GuestPhoneBook.BL;
using IGATEPATNI.GuestPhoneBook.DAL;
using IGATEPATNI.GuestPhoneBook.Entities;
using System.Collections.Generic;
using System;

namespace WpfPL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public partial class MainWindow : Window
    {
        private SqlConnection connection;
        private SqlCommand command;
        private SqlDataAdapter adapter;
        private SqlCommandBuilder builder;
        private DataSet dataSet;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void dataGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var obj = dataGrid.SelectedItem;
            txtguestid.Text = ((Guest)obj).GuestID.ToString();
            textBox1.Text = ((Guest)obj).GuestName.ToString();
            textBox2.Text = ((Guest)obj).GuestContactNumber.ToString();
        }

        private void button3_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int deleteGuestID;
                deleteGuestID = Convert.ToInt32(txtguestid.Text);
                Guest deleteGuest = GuestBL.SearchGuestBL(deleteGuestID);
                if (deleteGuest != null)
                {
                    bool guestdeleted = GuestBL.DeleteGuestBL(deleteGuestID);
                    if (guestdeleted)
                        Console.WriteLine("Guest Deleted");
                    else
                        Console.WriteLine("Guest not Deleted ");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            connection = new SqlConnection();
            connection.ConnectionString = ConfigurationManager.ConnectionStrings["training"].ConnectionString;

            command = connection.CreateCommand();
            adapter = new SqlDataAdapter(command);
            builder = new SqlCommandBuilder(adapter);
            dataSet = new DataSet();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {

            int searchGuestID;
            searchGuestID = Convert.ToInt32(txtguestid.Text);
            Guest searchGuest = GuestBL.SearchGuestBL(searchGuestID);
            if (searchGuest != null)
            {
                textBox1.Text = searchGuest.GuestName;
                textBox2.Text = searchGuest.GuestContactNumber;
            }
            else
            {
                MessageBox.Show("guestId not found");
            }

        }
        private void updategrid()
        {
            try
            {
                List<Guest> guestlist = GuestBL.GetAllGuestsBL();
                dataGrid.ItemsSource = guestlist;
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            

        }

        private void update_Click(object sender, RoutedEventArgs e)
        {
            int updateGuestID;
            updateGuestID = Convert.ToInt32(txtguestid.Text);
            Guest updatedGuest = GuestBL.SearchGuestBL(updateGuestID);
            if (updatedGuest != null)
            {

                 updatedGuest.GuestName= textBox1.Text ;

                //Console.WriteLine("Update PhoneNumber :");
                updatedGuest.GuestContactNumber=textBox2.Text ;

                 bool guestUpdated = GuestBL.UpdateGuestBL(updatedGuest);
                if (guestUpdated)
                   MessageBox.Show("Guest Details Updated");
                else
                    MessageBox.Show("Guest Details not Updated ");
            }
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            updategrid();
        }

        private void button4_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Guest newGuest = new Guest();
                //Console.WriteLine("Enter GuestID :");

                newGuest.GuestID = Convert.ToInt32(txtguestid.Text);
                //Console.WriteLine("Enter Guest Name :");

                newGuest.GuestName = textBox1.Text;
               // Console.WriteLine("Enter PhoneNumber :");
                newGuest.GuestContactNumber = textBox2.Text;
                bool guestAdded = GuestBL.AddGuestBL(newGuest);
                if (guestAdded)
                    MessageBox.Show("Guest Added");
                else
                    MessageBox.Show("Guest not Added");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}

